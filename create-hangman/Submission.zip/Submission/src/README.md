a hangman game allowing user to select a letter on the keyboard to guess if that letter is in a random word selected. If the user guesses incorrectly then the game is over and a loss is tallied. if the user guessed the correct letters completing the word then a win is tallied.

Technologies used:
HTML
CSS
Boostrap
JavaScript